<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Latihan 1</title>
  </head>
  <body bgcolor="aqua">

    <!-- <bgsound src="musik/musik.mp3"></bgsound> -->
    <table align="center" border="1" cellpadding="0" width="100%">
        
    </table>
    <h1 align="center">
        <marquee behavior="" direction="right scrolldelay="100>
        Welcome To My World
    </marquee>
    </h1>
    <p align="right" id="atas"><a href="#bawah">Ke Bawah</a></p>
    <p align="justify">
        <img src="img/arthas.jpg" alt="gambar profile" width="10%" hspace="10" />
            
        Perkenalkan Nama saya Mochamad Ilham Shalsabiela, saya adalah seorang mahasiswa yang tengah menempuh pendidikan di Universitas Muria Kudus dan saat ini telah berada di semester 6
    </p>

    <fieldset>
        <legend>
            <font size="5" color="green" face="calibri">
                Tentang
            </font>
        </legend>
    
    <ol type="A">
        <li>Profile </li>
        <ul type="square">
            <li>Nama        : Mochamad Ilham Shalsabiela</li>
            <li>Gender      : Laki-Laki</li>
            <li>Alamat      : Land Of Dawn</li>
            <li>Agama       : Islam</li>
            <li>NoHp        : 081215833265</li>
            <li>Cita-Cita   : Menjadi Elite Global</li>
            <li>Hobby</li>
            <ol type="A">
                <li>Menonton Film</li>
                <li>Membaca Novel</li>
                <li>Mendengarkan Musik</li>
            </ol>
        </ul>
        <br>
        <li>Genre Film Favorit</li>
        <ul type="disc">
            <li>Action</li>
            <li>Comedy</li>
            <li>Gore</li>
            <li>Advanture</li>
        </ul>
        <br>
        <li>Menu Favorit</li>
        <ul >
            <li> Makanan </li>
            <ol type="A">
                <li>Nazi Goreng</li>
                <li>Semua Makanan Yang Rasanya Enak</li>
            </ol>
            <li>Minuman</li>
            <ol type="A">
                <li>Semua Minuman Yang Rasanya Enak</li>
            </ol>
        </ul>
        
    </ol>
</fieldset>
<p align="right" id="bawah"><a href="#atas">Ke Atas</a></p>
  </body>
</html>