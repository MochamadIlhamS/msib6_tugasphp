<?php 
//include atau include once untuk potongan2 file
//require atau require_once untuk potongan2 file tapi isinya berupa function, class dll
//menggabungkan beberapa file menjadi 1 web utuh gunakan include

include_once 'atas.php';
include_once 'home.php';
include_once 'bawah.php';

 ?>