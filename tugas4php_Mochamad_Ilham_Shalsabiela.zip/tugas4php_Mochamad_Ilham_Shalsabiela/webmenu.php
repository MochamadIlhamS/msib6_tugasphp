<?php 
//array asosiatif
//menu untuk bagian atas (atas.php)
$menu_atas = [
		'home' => 'Home',
		'produk' => 'Produk',
		'pesan' => 'Pesan',
		'galeri' => 'Galeri',
		'gesbuk' => 'Gesbuk'
];
//menu untuk bagian bawah (isi.php)
$menu_bawah = [
		'home' => 'home.php',
		'produk' => 'produk.php',
		'pesan' => 'pesan.php',
		'galeri' => 'galeri.php',
		'gesbuk' => 'gesbuk.php'
];
 ?>