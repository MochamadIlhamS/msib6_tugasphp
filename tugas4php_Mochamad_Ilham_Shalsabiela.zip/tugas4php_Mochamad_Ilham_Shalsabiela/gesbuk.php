<?php 
include_once 'atas.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Daftar Buronan FBI</title>
  <style>
    body {
      font-family: Arial, sans-serif;
    }

    h1 {
      text-align: center;
    }

    ul {
      list-style-type: none;
      padding-left: 0;
    }

    li {
      margin-bottom: 20px;
      overflow: auto;
    }

    img {
      float: left;
      margin-right: 10px;
      width: 150px;
      height: auto;
    }
  </style>
</head>
<body>

<h1>Daftar Buronan FBI</h1>

<ul>
  <li>
    <img src="https://i.etsystatic.com/18015036/r/il/0e5b23/1544728598/il_794xN.1544728598_fvjb.jpg" alt="Buronan 1">
    <div>
      <strong>Nama:</strong> Bill Chipper<br>
      <strong>Umur:</strong> ?? Tahun<br>
      <strong>Deskripsi:</strong> ??.
    </div>
  </li>
  <li>
    <img src="https://pict.sindonews.net/webp/732/pena/news/2023/09/27/700/1212061/sukuna-tampakkan-wujud-asli-di-jujutsu-kaisen-237-megumi-mati-lta.webp">
    <div>
      <strong>Nama:</strong> Sukuna<br>
      <strong>Umur:</strong> ?? tahun<br>
      <strong>Deskripsi:</strong> Main Actor Tragedi Shibuya
    </div>
  </li>
  <li>
    <img src="https://cms.disway.id/uploads/2984917215f2042b700977f089d13cca.jpg" alt="Buronan 3">
    <div>
      <strong>Nama:</strong> Kratos<br>
      <strong>Umur:</strong> ?? tahun<br>
      <strong>Deskripsi:</strong> Bantai Bantai.
    </div>
  </li>
</ul>

</body>
</html>

<?php 
include_once 'bawah.php';
?>
